ALTER TABLE service_reports
ADD COLUMN IF NOT EXISTS start_date DATE,
ADD COLUMN IF NOT EXISTS start_time TIME,
ADD COLUMN IF NOT EXISTS end_date DATE, -- ¡Corregido aquí!
ADD COLUMN IF NOT EXISTS end_time TIME,
ADD COLUMN IF NOT EXISTS commitments TEXT,
ADD COLUMN IF NOT EXISTS recommendations TEXT,
ADD COLUMN IF NOT EXISTS remember_commitments BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS remember_recommendations BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS assigned_technician_ids TEXT[], -- Array de IDs de técnicos
ADD COLUMN IF NOT EXISTS assigned_technician_names TEXT[], -- Array de nombres de técnicos
ADD COLUMN IF NOT EXISTS checklist_id TEXT,
ADD COLUMN IF NOT EXISTS surveyed_person TEXT,
ADD COLUMN IF NOT EXISTS evaluation_type TEXT,
ADD COLUMN IF NOT EXISTS client_order_number TEXT,
ADD COLUMN IF NOT EXISTS responsible_person TEXT,
ADD COLUMN IF NOT EXISTS service_type_flags JSONB; -- Para almacenar los tipos de servicio como un objeto JSON
