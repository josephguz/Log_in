CREATE TABLE IF NOT EXISTS clients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  contact_person TEXT,
  phone TEXT,
  email TEXT,
  address TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE clients ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public clients are viewable by everyone."
  ON clients FOR SELECT
  USING (TRUE);

CREATE POLICY "Authenticated users can insert clients."
  ON clients FOR INSERT
  WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can update their own clients."
  ON clients FOR UPDATE
  USING (auth.uid() IS NOT NULL); -- Consider adding a user_id column to clients for ownership

CREATE POLICY "Authenticated users can delete their own clients."
  ON clients FOR DELETE
  USING (auth.uid() IS NOT NULL); -- Consider adding a user_id column to clients for ownership
