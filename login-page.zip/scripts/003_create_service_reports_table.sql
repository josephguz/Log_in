CREATE TABLE IF NOT EXISTS service_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  equipment_id UUID NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
  report_date DATE NOT NULL DEFAULT CURRENT_DATE,
  service_type TEXT NOT NULL,
  description TEXT,
  technician_notes TEXT,
  status TEXT NOT NULL DEFAULT 'Pendiente', -- Ej: 'Pendiente', 'Completado', 'En Progreso'
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE service_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public service_reports are viewable by everyone."
  ON service_reports FOR SELECT
  USING (TRUE);

CREATE POLICY "Authenticated users can insert service_reports."
  ON service_reports FOR INSERT
  WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can update their own service_reports."
  ON service_reports FOR UPDATE
  USING (auth.uid() IS NOT NULL); -- Consider adding a user_id column to service_reports for ownership

CREATE POLICY "Authenticated users can delete their own service_reports."
  ON service_reports FOR DELETE
  USING (auth.uid() IS NOT NULL); -- Consider adding a user_id column to service_reports for ownership
