CREATE TABLE IF NOT EXISTS equipment (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  model TEXT,
  serial_number TEXT UNIQUE,
  location TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE equipment ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public equipment are viewable by everyone."
  ON equipment FOR SELECT
  USING (TRUE);

CREATE POLICY "Authenticated users can insert equipment."
  ON equipment FOR INSERT
  WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can update their own equipment."
  ON equipment FOR UPDATE
  USING (auth.uid() IS NOT NULL); -- Consider adding a user_id column to equipment for ownership

CREATE POLICY "Authenticated users can delete their own equipment."
  ON equipment FOR DELETE
  USING (auth.uid() IS NOT NULL); -- Consider adding a user_id column to equipment for ownership
