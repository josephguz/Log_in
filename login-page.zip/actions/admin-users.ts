"use server"

import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { createSupabaseServerClient } from "@/lib/supabase"
import bcrypt from "bcryptjs" // Para hashear contraseñas de nuevos usuarios
import { revalidatePath } from "next/cache" // Para revalidar la página después de cambios

// Función de utilidad para verificar si el usuario es admin
async function checkAdminSession() {
  const session = await getServerSession(authOptions)
  if (!session || session.user?.role !== "admin") {
    throw new Error("Acceso denegado: No eres administrador.")
  }
  return session
}

// --- Operaciones CRUD ---

export async function approveUser(prevState: any, formData: FormData) {
  try {
    await checkAdminSession()
    const userId = formData.get("userId") as string
    const supabase = createSupabaseServerClient()

    const { error } = await supabase.from("custom_users").update({ is_approved: true }).eq("id", userId)

    if (error) {
      console.error("Error approving user:", error.message)
      return { success: false, message: `Error al aprobar usuario: ${error.message}` }
    }

    revalidatePath("/admin") // Revalidar la página de admin para mostrar los cambios
    return { success: true, message: "Usuario aprobado exitosamente.", userId } // Devolver userId
  } catch (error: any) {
    return { success: false, message: error.message || "Error desconocido al aprobar usuario." }
  }
}

export async function deleteUser(prevState: any, formData: FormData) {
  try {
    await checkAdminSession()
    const userId = formData.get("userId") as string
    const supabase = createSupabaseServerClient()

    console.log(`[deleteUser Action] Intentando eliminar usuario con ID: ${userId}`)

    // Intentar eliminar de auth.users de Supabase
    // Nota: Esto requiere SUPABASE_SERVICE_ROLE_KEY y permisos de admin.
    const { error: authError } = await supabase.auth.admin.deleteUser(userId)

    if (authError) {
      console.warn(
        `[deleteUser Action] Advertencia: No se pudo eliminar el usuario de Supabase Auth (ID: ${userId}). Posiblemente no existe allí o hay un problema de permisos:`,
        authError.message,
      )
      // No lanzamos error fatal aquí si el usuario solo existe en custom_users
    } else {
      console.log(`[deleteUser Action] Usuario eliminado de Supabase Auth (ID: ${userId}).`)
    }

    // Eliminar de custom_users
    const { error: dbError } = await supabase.from("custom_users").delete().eq("id", userId)

    if (dbError) {
      console.error(`[deleteUser Action] Error al eliminar usuario de custom_users (ID: ${userId}):`, dbError.message)
      return { success: false, message: `Error al eliminar usuario: ${dbError.message}` }
    }

    console.log(`[deleteUser Action] Usuario eliminado de custom_users (ID: ${userId}).`)
    revalidatePath("/admin")
    return { success: true, message: "Usuario eliminado exitosamente.", userId } // Devolver userId
  } catch (error: any) {
    console.error("[deleteUser Action] Error inesperado:", error.message)
    return { success: false, message: error.message || "Error desconocido al eliminar usuario." }
  }
}

export async function updateUserRole(prevState: any, formData: FormData) {
  try {
    await checkAdminSession()
    const userId = formData.get("userId") as string
    const newRole = formData.get("newRole") as string
    const supabase = createSupabaseServerClient()

    const { error } = await supabase.from("custom_users").update({ role: newRole }).eq("id", userId)

    if (error) {
      console.error("Error updating user role:", error.message)
      return { success: false, message: `Error al actualizar rol: ${error.message}` }
    }

    revalidatePath("/admin")
    return { success: true, message: "Rol de usuario actualizado exitosamente.", userId, newRole } // Devolver userId y newRole
  } catch (error: any) {
    return { success: false, message: error.message || "Error desconocido al actualizar rol." }
  }
}

export async function resetUserPassword(prevState: any, formData: FormData) {
  try {
    await checkAdminSession()
    const userId = formData.get("userId") as string
    const newPassword = formData.get("newPassword") as string

    if (newPassword.length < 6) {
      return { success: false, message: "La nueva contraseña debe tener al menos 6 caracteres." }
    }

    const supabase = createSupabaseServerClient()

    // Supabase Admin API para actualizar la contraseña
    const { data, error: authError } = await supabase.auth.admin.updateUserById(userId, {
      password: newPassword,
    })

    if (authError) {
      console.error("Error resetting password via Supabase Admin API:", authError.message)
      return { success: false, message: `Error al restablecer contraseña: ${authError.message}` }
    }

    // Si el usuario también está en custom_users, actualiza el hash ahí también
    // Esto es importante si tu CredentialsProvider usa custom_users para la verificación
    const hashedPassword = await bcrypt.hash(newPassword, 10)
    const { error: dbError } = await supabase
      .from("custom_users")
      .update({ hashed_password: hashedPassword })
      .eq("id", userId)

    if (dbError) {
      console.warn("Warning: Could not update hashed_password in custom_users table:", dbError.message)
      // No es un error fatal si la contraseña ya se actualizó en auth.users
    }

    revalidatePath("/admin")
    return { success: true, message: "Contraseña restablecida exitosamente." }
  } catch (error: any) {
    return { success: false, message: error.message || "Error desconocido al restablecer contraseña." }
  }
}

export async function createAdminUser(prevState: any, formData: FormData) {
  try {
    await checkAdminSession()
    const email = formData.get("email") as string
    const password = formData.get("password") as string
    const role = (formData.get("role") as string) || "user" // Default to 'user'

    if (!email || !password) {
      return { success: false, message: "Email y contraseña son requeridos." }
    }
    if (password.length < 6) {
      return { success: false, message: "La contraseña debe tener al menos 6 caracteres." }
    }

    const supabase = createSupabaseServerClient()

    // Crear usuario en Supabase Auth
    const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
      email: email,
      password: password,
      email_confirm: true, // O false si quieres que confirmen email
    })

    if (authError) {
      console.error("Error creating user via Supabase Admin API:", authError.message)
      return { success: false, message: `Error al crear usuario: ${authError.message}` }
    }

    // Hashear la contraseña para custom_users
    const hashedPassword = await bcrypt.hash(password, 10)

    // Insertar en custom_users
    const { error: dbError } = await supabase.from("custom_users").insert({
      id: authUser.user?.id, // Usar el ID de Supabase Auth
      email: email,
      hashed_password: hashedPassword,
      is_approved: true, // Los usuarios creados por admin se aprueban automáticamente
      role: role,
    })

    if (dbError) {
      console.error("Error inserting user into custom_users:", dbError.message)
      // Si falla aquí, considera eliminar el usuario de auth.users también
      await supabase.auth.admin.deleteUser(authUser.user?.id as string)
      return { success: false, message: `Error al crear usuario en DB: ${dbError.message}` }
    }

    revalidatePath("/admin")
    return { success: true, message: "Usuario creado exitosamente." }
  } catch (error: any) {
    return { success: false, message: error.message || "Error desconocido al crear usuario." }
  }
}
