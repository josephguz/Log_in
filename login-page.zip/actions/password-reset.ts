"use server"

import { createSupabaseServerClient } from "@/lib/supabase"

export async function requestPasswordReset(prevState: any, formData: FormData) {
  const email = formData.get("email") as string

  if (!email) {
    return { success: false, message: "Por favor, ingresa tu correo electrónico." }
  }

  try {
    const supabase = createSupabaseServerClient()

    // La URL a la que Supabase redirigirá al usuario después de hacer clic en el enlace del email.
    // Asegúrate de que NEXTAUTH_URL esté configurado en tus variables de entorno de Vercel.
    // Por ejemplo: https://tu-app.vercel.app/reset-password
    const redirectToUrl = `${process.env.NEXTAUTH_URL}/reset-password`

    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: redirectToUrl,
    })

    if (error) {
      console.error("Error al solicitar restablecimiento de contraseña:", error.message)
      // Supabase a veces devuelve un error genérico por seguridad si el email no existe.
      // Para evitar enumeración de usuarios, es mejor dar un mensaje genérico.
      return {
        success: false,
        message: "Ocurrió un error al enviar el enlace. Por favor, verifica tu correo e inténtalo de nuevo.",
      }
    }

    return {
      success: true,
      message: "Si tu correo está registrado, recibirás un enlace para restablecer tu contraseña.",
    }
  } catch (error: any) {
    console.error("Error inesperado en requestPasswordReset:", error.message)
    return { success: false, message: "Ocurrió un error inesperado. Inténtalo de nuevo más tarde." }
  }
}
