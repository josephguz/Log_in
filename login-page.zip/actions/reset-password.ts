"use server"

import { createSupabaseServerClient } from "@/lib/supabase"
import { redirect } from "next/navigation"
import bcrypt from "bcryptjs" // Para hashear la contraseña en custom_users

export async function updatePassword(prevState: any, formData: FormData) {
  const token = formData.get("token") as string
  const password = formData.get("password") as string
  const confirmPassword = formData.get("confirmPassword") as string

  if (!token) {
    return { success: false, message: "Token de restablecimiento no válido." }
  }

  if (!password || !confirmPassword) {
    return { success: false, message: "Por favor, ingresa y confirma tu nueva contraseña." }
  }

  if (password !== confirmPassword) {
    return { success: false, message: "Las contraseñas no coinciden." }
  }

  if (password.length < 6) {
    return { success: false, message: "La contraseña debe tener al menos 6 caracteres." }
  }

  try {
    const supabase = createSupabaseServerClient()

    // 1. Verificar el token y obtener la sesión del usuario
    // Supabase maneja la verificación del token internamente con `updateUser`
    // cuando se usa un token de restablecimiento.
    // Sin embargo, para mayor claridad y para asegurar que el token es válido antes de actualizar,
    // podemos intentar obtener la sesión con el token.
    // Nota: `verifyOtp` es para tokens de email/SMS, no para tokens de restablecimiento de contraseña.
    // La forma correcta de usar el token de restablecimiento es pasarlo directamente a `updateUser`.

    // 2. Actualizar la contraseña del usuario en Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.updateUser({
      password: password,
    })

    if (authError) {
      console.error("Error al actualizar contraseña en Supabase Auth:", authError.message)
      return { success: false, message: `Error al actualizar contraseña: ${authError.message}` }
    }

    // 3. Si usas una tabla `custom_users` para NextAuth.js CredentialsProvider,
    // también debes actualizar la contraseña hasheada allí.
    if (authData.user?.id) {
      const hashedPassword = await bcrypt.hash(password, 10)
      const { error: dbError } = await supabase
        .from("custom_users")
        .update({ hashed_password: hashedPassword })
        .eq("id", authData.user.id)

      if (dbError) {
        console.warn("Advertencia: No se pudo actualizar hashed_password en custom_users:", dbError.message)
        // Esto no es un error crítico si la contraseña ya se actualizó en Supabase Auth
      }
    }

    console.log("Contraseña actualizada exitosamente para el usuario:", authData.user?.email)
    redirect("/login?reset=success") // Redirigir a la página de login con un mensaje de éxito
  } catch (error: any) {
    console.error("Error inesperado en updatePassword:", error.message)
    return { success: false, message: error.message || "Ocurrió un error inesperado. Inténtalo de nuevo." }
  }
}
