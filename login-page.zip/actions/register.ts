"use server"

import { createSupabaseServerClient } from "@/lib/supabase"
import bcrypt from "bcryptjs"
import { redirect } from "next/navigation"

export async function registerUser(prevState: any, formData: FormData) {
  const email = formData.get("email") as string
  const password = formData.get("password") as string
  const confirmPassword = formData.get("confirmPassword") as string

  if (!email || !password || !confirmPassword) {
    return { success: false, message: "Por favor, completa todos los campos." }
  }

  if (password !== confirmPassword) {
    return { success: false, message: "Las contraseñas no coinciden." }
  }

  if (password.length < 6) {
    return { success: false, message: "La contraseña debe tener al menos 6 caracteres." }
  }

  try {
    const supabase = createSupabaseServerClient()

    // Verificar si el email ya existe
    const { data: existingUser, error: checkError } = await supabase
      .from("custom_users")
      .select("id")
      .eq("email", email)
      .single()

    if (existingUser) {
      return { success: false, message: "Este correo electrónico ya está registrado." }
    }
    if (checkError && checkError.code !== "PGRST116") {
      // PGRST116 es "no rows found"
      console.error("Error al verificar usuario existente:", checkError.message)
      throw new Error("Error al verificar usuario existente.")
    }

    // Hashear la contraseña
    const hashedPassword = await bcrypt.hash(password, 10) // 10 es el saltRounds

    // Insertar el nuevo usuario en la tabla custom_users
    const { error: insertError } = await supabase.from("custom_users").insert({
      email: email,
      hashed_password: hashedPassword,
      is_approved: false, // Por defecto, el usuario no está aprobado
      role: "user", // Por defecto, el rol es 'user'
    })

    if (insertError) {
      console.error("Error al registrar usuario en Supabase:", insertError.message)
      throw new Error("Error al registrar usuario. Inténtalo de nuevo.")
    }

    console.log("Usuario registrado exitosamente (pendiente de aprobación):", email)
    redirect("/pending-approval") // Redirigir a la página de pendiente de aprobación
  } catch (error: any) {
    console.error("Error en el registro:", error.message)
    return { success: false, message: error.message || "Ocurrió un error inesperado durante el registro." }
  }
}
