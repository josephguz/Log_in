"use server"

// En una aplicación real, aquí conectarías con tu base de datos
// y verificarías las credenciales de forma segura (ej. con bcrypt para contraseñas).

export async function login(prevState: any, formData: FormData) {
  const email = formData.get("email") as string
  const password = formData.get("password") as string

  // Simulación de validación básica
  if (!email || !password) {
    return { success: false, message: "Por favor, ingresa tu correo y contraseña." }
  }

  // Simulación de un retraso de red
  await new Promise((resolve) => setTimeout(resolve, 1500))

  // Simulación de verificación de credenciales
  // ¡ADVERTENCIA! En producción, NUNCA uses credenciales hardcodeadas.
  // Siempre verifica contra una base de datos y usa hashing de contraseñas.
  if (email === "test@example.com" && password === "password123") {
    // En una aplicación real, aquí establecerías una sesión de usuario (ej. con cookies seguras)
    console.log("Inicio de sesión exitoso para:", email)
    return { success: true, message: "¡Inicio de sesión exitoso!" }
  } else {
    console.log("Intento de inicio de sesión fallido para:", email)
    return { success: false, message: "Correo electrónico o contraseña incorrectos." }
  }
}
