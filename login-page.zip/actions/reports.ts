"use server"

import { createSupabaseServerClient } from "@/lib/supabase"
import { revalidatePath } from "next/cache"

// Tipos para las tablas (actualizados para incluir todos los campos del formulario)
export type Client = {
  id: string
  name: string
  contact_person?: string
  phone?: string
  email?: string
  address?: string
  created_at: string
}

export type Equipment = {
  id: string
  client_id: string
  name: string
  model?: string
  brand?: string // Nuevo campo
  serial_number?: string
  inventory_number?: string // Nuevo campo
  location?: string
  created_at: string
}

export type ServiceReport = {
  id: string
  equipment_id: string
  report_date: string // Formato YYYY-MM-DD
  start_date?: string // Nuevo campo
  start_time?: string // Nuevo campo
  end_date?: string // Nuevo campo
  end_time?: string // Nuevo campo
  service_type: string
  description?: string
  technician_notes?: string
  status: string
  commitments?: string // Nuevo campo
  recommendations?: string // Nuevo campo
  remember_commitments?: boolean // Nuevo campo
  remember_recommendations?: boolean // Nuevo campo
  assigned_technician_ids?: string[] // Nuevo campo
  assigned_technician_names?: string[] // Nuevo campo
  checklist_id?: string // Nuevo campo
  surveyed_person?: string // Nuevo campo
  evaluation_type?: string // Nuevo campo
  client_order_number?: string // Nuevo campo
  responsible_person?: string // Nuevo campo
  service_type_flags?: Record<string, boolean> // Nuevo campo (JSONB)
  created_at: string
}

// --- Funciones de Lectura ---

export async function getClients(searchQuery?: string): Promise<Client[]> {
  const supabase = createSupabaseServerClient()
  let query = supabase.from("clients").select("*").order("name", { ascending: true })

  if (searchQuery) {
    // Buscar por nombre o email del cliente
    query = query.or(`name.ilike.%${searchQuery}%,email.ilike.%${searchQuery}%`)
  }

  const { data, error } = await query

  if (error) {
    console.error("Error fetching clients:", error.message)
    return []
  }
  return data as Client[]
}

export async function getEquipmentByClientId(clientId: string, searchQuery?: string): Promise<Equipment[]> {
  const supabase = createSupabaseServerClient()
  let query = supabase.from("equipment").select("*").eq("client_id", clientId).order("name", { ascending: true })

  if (searchQuery) {
    // Buscar por nombre, modelo, marca, número de serie o número de inventario
    query = query.or(
      `name.ilike.%${searchQuery}%,model.ilike.%${searchQuery}%,brand.ilike.%${searchQuery}%,serial_number.ilike.%${searchQuery}%,inventory_number.ilike.%${searchQuery}%`,
    )
  }

  const { data, error } = await query

  if (error) {
    console.error("Error fetching equipment:", error.message)
    return []
  }
  return data as Equipment[]
}

export async function getServiceReportsByEquipmentId(equipmentId: string): Promise<ServiceReport[]> {
  const supabase = createSupabaseServerClient()
  const { data, error } = await supabase
    .from("service_reports")
    .select("*")
    .eq("equipment_id", equipmentId)
    .order("report_date", { ascending: false })

  if (error) {
    console.error("Error fetching service reports:", error.message)
    return []
  }
  return data as ServiceReport[]
}

// --- Funciones de Escritura (CRUD) - Actualizadas para nuevos campos ---

export async function createClient(prevState: any, formData: FormData) {
  const name = formData.get("clienteNombre") as string // Mapeado desde el formulario
  const phone = formData.get("clienteTelefono") as string // Mapeado desde el formulario
  const email = formData.get("clienteEmail") as string // Mapeado desde el formulario
  // contact_person y address no están directamente en el formulario Kaika, se pueden dejar opcionales o eliminar si no se usan
  const contact_person = (formData.get("contact_person") as string) || null
  const address = (formData.get("address") as string) || null

  if (!name) {
    return { success: false, message: "El nombre del cliente es requerido." }
  }

  const supabase = createSupabaseServerClient()
  const { error } = await supabase.from("clients").insert({
    name,
    contact_person,
    phone,
    email,
    address,
  })

  if (error) {
    console.error("Error creating client:", error.message)
    return { success: false, message: `Error al crear cliente: ${error.message}` }
  }

  revalidatePath("/reports") // Revalidar la página para mostrar el nuevo cliente
  return { success: true, message: "Cliente creado exitosamente." }
}

export async function createEquipment(prevState: any, formData: FormData) {
  const client_id = formData.get("client_id") as string // Este debe venir de la selección del cliente
  const name = formData.get("name") as string // ¡CORREGIDO! Antes era "equipoNombre"
  const model = formData.get("model") as string // ¡CORREGIDO! Antes era "equipoModelo"
  const brand = formData.get("brand") as string // ¡CORREGIDO! Antes era "equipoMarca"
  const serial_number = formData.get("serial_number") as string // ¡CORREGIDO! Antes era "equipoSerial"
  const inventory_number = formData.get("inventory_number") as string // ¡CORREGIDO! Antes era "equipoNoInv"
  const location = formData.get("location") as string // ¡CORREGIDO! Antes era "equipoUbicacion"

  if (!client_id || !name) {
    return { success: false, message: "El cliente y el nombre del equipo son requeridos." }
  }

  const supabase = createSupabaseServerClient()
  const { error } = await supabase.from("equipment").insert({
    client_id,
    name,
    model,
    brand,
    serial_number,
    inventory_number,
    location,
  })

  if (error) {
    console.error("Error creating equipment:", error.message)
    return { success: false, message: `Error al crear equipo: ${error.message}` }
  }

  revalidatePath("/reports") // Revalidar la página
  return { success: true, message: "Equipo creado exitosamente." }
}

export async function createServiceReport(prevState: any, formData: FormData) {
  const equipment_id = formData.get("equipment_id") as string
  const report_date = formData.get("report_date") as string // Ya existía
  const service_type = formData.get("service_type") as string // Ya existía
  const description = formData.get("description") as string
  const technician_notes = formData.get("technician_notes") as string
  const status = formData.get("status") as string // Ya existía

  // Nuevos campos del formulario
  const start_date = formData.get("fechaInicio") as string
  const start_time = formData.get("horaInicio") as string
  const end_date = formData.get("fechaFin") as string
  const end_time = formData.get("horaFin") as string
  const commitments = formData.get("compromisos") as string
  const recommendations = formData.get("recomendaciones") as string
  const remember_commitments = formData.get("recordarCompromiso") === "true" // Checkbox
  const remember_recommendations = formData.get("recordarRecomendaciones") === "true" // Checkbox
  const checklist_id = formData.get("listaChequeo") as string
  const surveyed_person = formData.get("personaEncuestada") as string
  const evaluation_type = formData.get("tipoEvaluacion") as string
  const client_order_number = formData.get("ordenClienteNo") as string
  const responsible_person = formData.get("encargado") as string

  // Manejo de serviceTypes (checkboxes) como JSONB
  const serviceTypeFlags: Record<string, boolean> = {}
  // Asumiendo que el formulario envía los serviceTypes como un string JSON o campos individuales
  // Para este ejemplo, si vienen como un string JSON:
  const serviceTypesJsonString = formData.get("serviceTypes") as string
  if (serviceTypesJsonString) {
    try {
      const parsedServiceTypes = JSON.parse(serviceTypesJsonString)
      Object.assign(serviceTypeFlags, parsedServiceTypes)
    } catch (e) {
      console.error("Error parsing serviceTypes JSON:", e)
    }
  }

  // Manejo de técnicos asignados (asumiendo que vienen como un JSON string o similar)
  // Para simplificar, asumiremos que el formulario enviará un string JSON de IDs y nombres
  const assigned_technician_ids_str = formData.get("assigned_technician_ids") as string
  const assigned_technician_names_str = formData.get("assigned_technician_names") as string

  let assigned_technician_ids: string[] = []
  let assigned_technician_names: string[] = []

  try {
    if (assigned_technician_ids_str) {
      assigned_technician_ids = JSON.parse(assigned_technician_ids_str)
    }
    if (assigned_technician_names_str) {
      assigned_technician_names = JSON.parse(assigned_technician_names_str)
    }
  } catch (e) {
    console.error("Error parsing assigned technicians:", e)
  }

  if (!equipment_id || !report_date || !service_type || !status) {
    return { success: false, message: "Equipo, fecha, tipo de servicio y estado son requeridos." }
  }

  const supabase = createSupabaseServerClient()
  const { error } = await supabase.from("service_reports").insert({
    equipment_id,
    report_date,
    service_type,
    description,
    technician_notes,
    status,
    start_date,
    start_time,
    end_date,
    end_time,
    commitments,
    recommendations,
    remember_commitments,
    remember_recommendations,
    assigned_technician_ids,
    assigned_technician_names,
    checklist_id,
    surveyed_person,
    evaluation_type,
    client_order_number,
    responsible_person,
    service_type_flags: serviceTypeFlags, // Guardar como JSONB
  })

  if (error) {
    console.error("Error creating service report:", error.message)
    return { success: false, message: `Error al crear reporte de servicio: ${error.message}` }
  }

  revalidatePath("/reports") // Revalidar la página
  return { success: true, message: "Reporte de servicio creado exitosamente." }
}
