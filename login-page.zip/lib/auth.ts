import type { NextAuthOptions, DefaultSession } from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"
import { createSupabaseServerClient } from "@/lib/supabase"
import bcrypt from "bcryptjs" // Asegúrate de tener 'bcryptjs' instalado

export const authOptions: NextAuthOptions = {
  pages: {
    signIn: "/login", // Redirige a tu página de login si no está autenticado
  },
  providers: [
    CredentialsProvider({
      name: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        console.log("[Auth] authorize function called.")
        console.log("[Auth] Credentials received:", {
          email: credentials?.email,
          password: credentials?.password ? "[REDACTED]" : "N/A",
        })

        if (!credentials?.email || !credentials?.password) {
          console.error("[Auth] Error: Missing email or password in credentials.")
          throw new Error("Missing email or password in credentials.")
        }

        try {
          console.log("[Auth] Checking environment variables...")
          const supabaseUrl = process.env.SUPABASE_URL
          const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY
          const authSecret = process.env.AUTH_SECRET
          const nextAuthUrl = process.env.NEXTAUTH_URL

          console.log(`[Auth] SUPABASE_URL: ${supabaseUrl ? "Set" : "Undefined"}`)
          console.log(`[Auth] SUPABASE_SERVICE_ROLE_KEY: ${supabaseServiceRoleKey ? "Set" : "Undefined"}`)
          console.log(`[Auth] AUTH_SECRET: ${authSecret ? "Set" : "Undefined"}`)
          console.log(`[Auth] NEXTAUTH_URL: ${nextAuthUrl ? "Set" : "Undefined"}`)

          if (!supabaseUrl || !supabaseServiceRoleKey || !authSecret || !nextAuthUrl) {
            console.error("[Auth] CRITICAL ERROR: One or more environment variables are missing or undefined.")
            throw new Error("Missing critical environment variables for authentication.")
          }

          console.log("[Auth] Attempting to create Supabase client...")
          const supabase = createSupabaseServerClient()
          console.log("[Auth] Supabase client created successfully.")

          console.log(`[Auth] Querying custom_users table for email: ${credentials.email}`)
          const { data: user, error: supabaseError } = await supabase
            .from("custom_users") // Asegúrate de que esta tabla exista en Supabase
            .select("id, email, hashed_password, is_approved, role") // Añadir is_approved y role
            .eq("email", credentials.email)
            .single()

          if (supabaseError) {
            console.error("[Auth] Supabase query error:", supabaseError.message)
            if (supabaseError.code === "PGRST116") {
              console.log("[Auth] User not found in custom_users table.")
            }
            throw new Error("User not found or database error.")
          }

          if (!user) {
            console.log("[Auth] User not found for email:", credentials.email)
            throw new Error("User not found.")
          }

          console.log("[Auth] User found in DB:", user.email)

          // Verificar si el usuario está aprobado
          if (!user.is_approved) {
            console.log("[Auth] User not approved:", user.email)
            throw new Error("Your account is pending administrator approval.")
          }

          console.log("[Auth] Comparing passwords using bcrypt...")
          const passwordMatch = await bcrypt.compare(credentials.password as string, user.hashed_password)
          console.log("[Auth] Password comparison result:", passwordMatch)

          if (passwordMatch) {
            console.log("[Auth] Password matched. User authorized successfully.")
            return {
              id: user.id,
              email: user.email,
              is_approved: user.is_approved, // Añadir a la sesión
              role: user.role, // Añadir a la sesión
            }
          } else {
            console.log("[Auth] Password incorrect for user:", credentials.email)
            throw new Error("Incorrect password.")
          }
        } catch (error) {
          console.error("[Auth] Unhandled exception in authorize function:", error)
          throw error
        }
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id
        token.is_approved = (user as any).is_approved // Asegurarse de que el tipo sea correcto
        token.role = (user as any).role // Asegurarse de que el tipo sea correcto
      }
      return token
    },
    async session({ session, token }) {
      if (token.id) {
        session.user.id = token.id as string
        session.user.is_approved = token.is_approved as boolean // Añadir a la sesión
        session.user.role = token.role as string // Añadir a la sesión
      }
      return session
    },
  },
}

// Extender los tipos de NextAuth para incluir las nuevas propiedades
declare module "next-auth" {
  interface Session {
    user: {
      id: string
      email: string
      is_approved: boolean
      role: string
    } & DefaultSession["user"]
  }

  interface User {
    id: string
    email: string
    is_approved: boolean
    role: string
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id: string
    is_approved: boolean
    role: string
  }
}
