"use client"

import { useRef, useEffect, useState, useCallback } from "react"
import SignaturePad from "react-signature-canvas"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { RotateCcw, Eraser } from "lucide-react"

interface SignatureCaptureProps {
  onSignatureSave: (data: string) => void
  currentSignature?: string
}

export default function SignatureCapture({ onSignatureSave, currentSignature }: SignatureCaptureProps) {
  const sigCanvas = useRef<any>(null)
  const [isEmpty, setIsEmpty] = useState(true)

  useEffect(() => {
    if (sigCanvas.current && currentSignature) {
      sigCanvas.current.fromDataURL(currentSignature)
      setIsEmpty(false)
    }
  }, [currentSignature])

  const clearSignature = useCallback(() => {
    sigCanvas.current.clear()
    setIsEmpty(true)
    onSignatureSave("")
  }, [onSignatureSave])

  const saveSignature = useCallback(() => {
    if (!sigCanvas.current.isEmpty()) {
      onSignatureSave(sigCanvas.current.toDataURL())
      setIsEmpty(false)
    }
  }, [onSignatureSave])

  return (
    <Card className="w-full max-w-md">
      <CardContent className="p-4">
        <div className="border border-gray-300 rounded-md overflow-hidden">
          <SignaturePad
            ref={sigCanvas}
            canvasProps={{
              width: 300,
              height: 100,
              className: "signature-canvas bg-gray-50",
            }}
            onEnd={saveSignature}
            onBegin={() => setIsEmpty(false)}
          />
        </div>
        <div className="flex gap-2 mt-4">
          <Button onClick={clearSignature} variant="outline" size="sm" disabled={isEmpty}>
            <Eraser className="h-4 w-4 mr-2" /> Borrar
          </Button>
          <Button onClick={saveSignature} size="sm" disabled={isEmpty}>
            <RotateCcw className="h-4 w-4 mr-2" /> Guardar
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
