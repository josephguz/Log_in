"use client"

import type React from "react"
import { useState, useEffect, useActionState } from "react"
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { approveUser, deleteUser, updateUserRole, resetUserPassword, createAdminUser } from "@/actions/admin-users"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/hooks/use-toast"

interface User {
  id: string
  email: string
  is_approved: boolean
  role: string
  created_at: string
}

interface AdminUserTableProps {
  initialUsers: User[]
}

export default function AdminUserTable({ initialUsers }: AdminUserTableProps) {
  const [users, setUsers] = useState<User[]>(initialUsers)
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [isResetPasswordDialogOpen, setIsResetPasswordDialogOpen] = useState(false)
  const [isCreateUserDialogOpen, setIsCreateUserDialogOpen] = useState(false)
  const [newPassword, setNewPassword] = useState("")
  const [newEmail, setNewEmail] = useState("")
  const [newCreatePassword, setNewCreatePassword] = useState("")
  const [newRole, setNewRole] = useState("user")

  // Action states for various operations
  const [approveState, approveAction, isApproving] = useActionState(approveUser, { success: false, message: "" })
  const [deleteState, deleteAction, isDeleting] = useActionState(deleteUser, { success: false, message: "" })
  const [updateRoleState, updateRoleAction, isUpdatingRole] = useActionState(updateUserRole, {
    success: false,
    message: "",
  })
  const [resetPasswordState, resetPasswordAction, isResettingPassword] = useActionState(resetUserPassword, {
    success: false,
    message: "",
  })
  const [createUserState, createUserAction, isCreatingUser] = useActionState(createAdminUser, {
    success: false,
    message: "",
  })

  // Handle action results with toast and update local state if successful
  useEffect(() => {
    if (approveState.message) {
      toast({
        title: approveState.success ? "Éxito" : "Error",
        description: approveState.message,
        variant: approveState.success ? "default" : "destructive",
      })
      if (approveState.success) {
        setUsers((prevUsers) =>
          prevUsers.map((user) => (user.id === (approveState as any).userId ? { ...user, is_approved: true } : user)),
        )
      }
    }
  }, [approveState])

  useEffect(() => {
    if (deleteState.message) {
      toast({
        title: deleteState.success ? "Éxito" : "Error",
        description: deleteState.message,
        variant: deleteState.success ? "default" : "destructive",
      })
      if (deleteState.success) {
        setUsers((prevUsers) => prevUsers.filter((user) => user.id !== (deleteState as any).userId))
      }
    }
  }, [deleteState])

  useEffect(() => {
    if (updateRoleState.message) {
      toast({
        title: updateRoleState.success ? "Éxito" : "Error",
        description: updateRoleState.message,
        variant: updateRoleState.success ? "default" : "destructive",
      })
      if (updateRoleState.success) {
        setUsers((prevUsers) =>
          prevUsers.map((user) =>
            user.id === (updateRoleState as any).userId ? { ...user, role: (updateRoleState as any).newRole } : user,
          ),
        )
      }
    }
  }, [updateRoleState])

  useEffect(() => {
    if (resetPasswordState.message) {
      toast({
        title: resetPasswordState.success ? "Éxito" : "Error",
        description: resetPasswordState.message,
        variant: resetPasswordState.success ? "default" : "destructive",
      })
      if (resetPasswordState.success) setIsResetPasswordDialogOpen(false)
    }
  }, [resetPasswordState])

  useEffect(() => {
    if (createUserState.message) {
      toast({
        title: createUserState.success ? "Éxito" : "Error",
        description: createUserState.message,
        variant: createUserState.success ? "default" : "destructive",
      })
      if (createUserState.success) {
        setIsCreateUserDialogOpen(false)
        setNewEmail("")
        setNewCreatePassword("")
        setNewRole("user")
        // Re-fetch users or add the new user to the state if the action returns the new user data
        // For now, relying on revalidatePath in the action, but a direct state update is faster.
        // If createAdminUser action returns the new user, you can do:
        // setUsers(prevUsers => [...prevUsers, (createUserState as any).newUser]);
      }
    }
  }, [createUserState])

  const handleResetPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (selectedUser) {
      const formData = new FormData()
      formData.append("userId", selectedUser.id)
      formData.append("newPassword", newPassword)
      resetPasswordAction(formData)
    }
  }

  const handleCreateUserSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const formData = new FormData()
    formData.append("email", newEmail)
    formData.append("password", newCreatePassword)
    formData.append("role", newRole)
    createUserAction(formData)
  }

  return (
    <div className="container mx-auto py-10">
      <div className="flex justify-end mb-4">
        <Button onClick={() => setIsCreateUserDialogOpen(true)}>Añadir Nuevo Usuario</Button>
      </div>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Email</TableHead>
              <TableHead>Rol</TableHead>
              <TableHead>Aprobado</TableHead>
              <TableHead>Fecha de Registro</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users.map((user) => (
              <TableRow key={user.id}>
                <TableCell className="font-medium">{user.email}</TableCell>
                <TableCell>
                  <form action={updateUserRole} className="flex items-center gap-2">
                    <input type="hidden" name="userId" value={user.id} />
                    <Select
                      name="newRole"
                      defaultValue={user.role}
                      onValueChange={(value) => {
                        const formData = new FormData()
                        formData.append("userId", user.id)
                        formData.append("newRole", value)
                        updateUserRole(formData)
                      }}
                      disabled={isUpdatingRole}
                    >
                      <SelectTrigger className="w-[120px]">
                        <SelectValue placeholder="Seleccionar Rol" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="user">Usuario</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                  </form>
                </TableCell>
                <TableCell>
                  <form action={approveUser}>
                    <input type="hidden" name="userId" value={user.id} />
                    <Button
                      variant={user.is_approved ? "outline" : "default"}
                      size="sm"
                      disabled={user.is_approved || isApproving}
                      type="submit"
                    >
                      {user.is_approved ? "Aprobado" : "Aprobar"}
                    </Button>
                  </form>
                </TableCell>
                <TableCell>{new Date(user.created_at).toLocaleDateString()}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => {
                        setSelectedUser(user)
                        setIsResetPasswordDialogOpen(true)
                      }}
                    >
                      Restablecer Contraseña
                    </Button>
                    {/* El botón de eliminar ahora usa un formulario para la acción */}
                    <form action={deleteAction}>
                      <input type="hidden" name="userId" value={user.id} />
                      <Button variant="destructive" size="sm" type="submit" disabled={isDeleting}>
                        Eliminar
                      </Button>
                    </form>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Dialogo para Restablecer Contraseña */}
      <Dialog open={isResetPasswordDialogOpen} onOpenChange={setIsResetPasswordDialogOpen}>
        {/* Se añadió 'bg-white' y 'text-black' para asegurar el fondo blanco y texto legible */}
        <DialogContent className="bg-white text-black">
          <DialogHeader>
            <DialogTitle>Restablecer Contraseña para {selectedUser?.email}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleResetPasswordSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="newPassword" className="text-right">
                  Nueva Contraseña
                </Label>
                <Input
                  id="newPassword"
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="col-span-3"
                  required
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsResetPasswordDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={isResettingPassword}>
                {isResettingPassword ? "Restableciendo..." : "Restablecer"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Dialogo para Añadir Nuevo Usuario */}
      <Dialog open={isCreateUserDialogOpen} onOpenChange={setIsCreateUserDialogOpen}>
        <DialogContent className="bg-white text-black">
          <DialogHeader>
            <DialogTitle>Añadir Nuevo Usuario</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleCreateUserSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="createEmail" className="text-right">
                  Email
                </Label>
                <Input
                  id="createEmail"
                  type="email"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="createPassword" className="text-right">
                  Contraseña
                </Label>
                <Input
                  id="createPassword"
                  type="password"
                  value={newCreatePassword}
                  onChange={(e) => setNewCreatePassword(e.target.value)}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="createRole" className="text-right">
                  Rol
                </Label>
                <Select
                  name="role"
                  defaultValue="user"
                  value={newRole}
                  onValueChange={setNewRole}
                  disabled={isCreatingUser}
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Seleccionar Rol" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="user">Usuario</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsCreateUserDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={isCreatingUser}>
                {isCreatingUser ? "Creando..." : "Crear Usuario"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
