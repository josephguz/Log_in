interface PdfReportContentProps {
  formData: any
  signature: string
  tecnicosAsignados: { id: string; nombre: string }[]
  actividadesSeleccionadas: string[]
  actividadesList: { id: string; nombre: string; categoria: string; seleccionada: boolean }[]
  pdfExportOptions: { includeFullReport: boolean }
}

export default function PdfReportContent({
  formData,
  signature,
  tecnicosAsignados,
  actividadesSeleccionadas,
  actividadesList,
  pdfExportOptions,
}: PdfReportContentProps) {
  if (!pdfExportOptions.includeFullReport) {
    return null // No renderizar si no se debe incluir el reporte completo
  }

  const selectedActivitiesDetails = actividadesList.filter((act) => actividadesSeleccionadas.includes(act.id))

  return (
    <div className="p-8 bg-white text-black font-sans text-sm" style={{ width: "210mm", minHeight: "297mm" }}>
      <h1 className="text-xl font-bold mb-4 text-center">REPORTE DE SERVICIO TÉCNICO</h1>

      {/* Sección de Cliente y Equipo */}
      <div className="mb-6 border p-4 rounded-md">
        <h2 className="text-lg font-semibold mb-2">Detalles del Cliente y Equipo</h2>
        <div className="grid grid-cols-2 gap-2">
          <p>
            <strong>CLIENTE:</strong> {formData.clienteNombre}
          </p>
          <p>
            <strong>TELEFONO:</strong> {formData.clienteTelefono}
          </p>
          <p>
            <strong>E-MAIL:</strong> {formData.clienteEmail}
          </p>
          <p>
            <strong>EQUIPO:</strong> {formData.equipoNombre}
          </p>
          <p>
            <strong>MODELO:</strong> {formData.equipoModelo}
          </p>
          <p>
            <strong>MARCA:</strong> {formData.equipoMarca}
          </p>
          <p>
            <strong>SERIAL:</strong> {formData.equipoSerial}
          </p>
          <p>
            <strong>No. INV:</strong> {formData.equipoNoInv}
          </p>
          <p>
            <strong>UBICACION:</strong> {formData.equipoUbicacion}
          </p>
          <p>
            <strong>ORDEN DE CLIENTE No.:</strong> {formData.ordenClienteNo}
          </p>
          <p>
            <strong>ENCARGADO:</strong> {formData.encargado}
          </p>
        </div>
      </div>

      {/* Sección de Tipo de Servicio */}
      <div className="mb-6 border p-4 rounded-md">
        <h2 className="text-lg font-semibold mb-2">Tipo de Servicio</h2>
        <div className="grid grid-cols-2 gap-2">
          {Object.entries(formData.serviceTypes).map(([key, value]) =>
            value ? (
              <p key={key}>
                -{" "}
                {key.charAt(0).toUpperCase() +
                  key
                    .slice(1)
                    .replace(/([A-Z])/g, " $1")
                    .trim()}
              </p>
            ) : null,
          )}
        </div>
      </div>

      {/* Sección de Información Básica */}
      <div className="mb-6 border p-4 rounded-md">
        <h2 className="text-lg font-semibold mb-2">Información Básica</h2>
        <p>
          <strong>Inicio:</strong> {formData.fechaInicio} {formData.horaInicio}
        </p>
        <p>
          <strong>Fin:</strong> {formData.fechaFin} {formData.horaFin}
        </p>
        <p>
          <strong>Trabajos Realizados:</strong> {formData.trabajos}
        </p>
        <p>
          <strong>Compromisos:</strong> {formData.compromisos} {formData.recordarCompromiso ? "(Recordar)" : ""}
        </p>
        <p>
          <strong>Recomendaciones:</strong> {formData.recomendaciones}{" "}
          {formData.recordarRecomendaciones ? "(Recordar)" : ""}
        </p>
      </div>

      {/* Sección de Técnicos Asignados */}
      <div className="mb-6 border p-4 rounded-md">
        <h2 className="text-lg font-semibold mb-2">Técnicos Asignados</h2>
        {tecnicosAsignados.length > 0 ? (
          <ul>
            {tecnicosAsignados.map((tec) => (
              <li key={tec.id}>- {tec.nombre}</li>
            ))}
          </ul>
        ) : (
          <p>No hay técnicos asignados.</p>
        )}
      </div>

      {/* Sección de Actividades */}
      <div className="mb-6 border p-4 rounded-md">
        <h2 className="text-lg font-semibold mb-2">Actividades Realizadas</h2>
        {selectedActivitiesDetails.length > 0 ? (
          <ul>
            {selectedActivitiesDetails.map((act) => (
              <li key={act.id}>- {act.nombre}</li>
            ))}
          </ul>
        ) : (
          <p>No hay actividades seleccionadas.</p>
        )}
      </div>

      {/* Sección de Evaluación */}
      <div className="mb-6 border p-4 rounded-md">
        <h2 className="text-lg font-semibold mb-2">Evaluación</h2>
        <p>
          <strong>Persona Encuestada:</strong> {formData.personaEncuestada}
        </p>
        <p>
          <strong>Tipo de Evaluación:</strong> {formData.tipoEvaluacion}
        </p>
      </div>

      {/* Sección de Firma */}
      <div className="mb-6 border p-4 rounded-md text-center">
        <h2 className="text-lg font-semibold mb-2">Firma del Técnico</h2>
        {signature ? (
          <img
            src={signature || "/placeholder.svg"}
            alt="Firma del Técnico"
            className="mx-auto border border-gray-300"
            style={{ maxWidth: "200px", height: "80px" }}
          />
        ) : (
          <p>No se ha capturado la firma.</p>
        )}
      </div>
    </div>
  )
}
