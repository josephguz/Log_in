"use client"

import { signOut } from "next-auth/react"
import { Button } from "@/components/ui/button"
import { useTransition } from "react" // Para manejar el estado de carga

export default function LogoutButton() {
  const [isPending, startTransition] = useTransition()

  const handleLogout = () => {
    startTransition(async () => {
      await signOut({ redirectTo: "/login" })
    })
  }

  return (
    <Button
      onClick={handleLogout}
      disabled={isPending}
      className="bg-white text-purple-700 hover:bg-gray-100 font-bold py-3 px-6 rounded-full shadow-lg transition-all duration-300 ease-in-out hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
    >
      {isPending ? "Cerrando Sesión..." : "Cerrar Sesión"}
    </Button>
  )
}
