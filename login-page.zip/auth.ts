import NextAuth from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"
import { createSupabaseServerClient } from "@/lib/supabase" // Importa tu cliente de Supabase
import bcrypt from "bcryptjs" // Necesitarás instalar 'bcryptjs'

export const {
  handlers: { GET, POST },
  auth,
  signIn,
  signOut,
} = NextAuth({
  pages: {
    signIn: "/login", // Redirige a tu página de login si no está autenticado
  },
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const supabase = createSupabaseServerClient()

        // 1. Buscar el usuario por email en la tabla auth.users de Supabase
        // Nota: Supabase almacena las contraseñas hasheadas en auth.users.
        // Para verificar, necesitamos la contraseña en texto plano y compararla con el hash.
        // Supabase no expone directamente el hash de la contraseña para comparación directa
        // con CredentialsProvider. La forma más segura es usar la función de login de Supabase
        // o, si usas una tabla de usuarios personalizada, almacenar tus propios hashes.

        // Para este ejemplo, vamos a simular la verificación de contraseña
        // contra un usuario registrado en Supabase Auth.
        // En un escenario real con CredentialsProvider y Supabase,
        // la forma más segura es que tu tabla de usuarios personalizada
        // almacene el hash de la contraseña y lo compares con bcrypt.

        // **Alternativa más segura para Supabase con CredentialsProvider:**
        // Si quieres usar CredentialsProvider y verificar contra Supabase Auth,
        // la forma más directa es usar el método signInWithPassword de Supabase.
        // Sin embargo, NextAuth.js espera un objeto de usuario.
        // Una mejor práctica es que NextAuth.js use un proveedor de Supabase si está disponible,
        // o que tu tabla de usuarios personalizada almacene el hash de la contraseña.

        // Para demostrar la funcionalidad de CredentialsProvider con una verificación de contraseña,
        // vamos a asumir que tienes una tabla `custom_users` con `email` y `hashed_password`.
        // Si solo usas Supabase Auth, considera usar el proveedor de Supabase para NextAuth.js.

        // --- SIMULACIÓN DE VERIFICACIÓN CONTRA UNA TABLA PERSONALIZADA ---
        // En Supabase, crea una tabla llamada `custom_users` con columnas:
        // id (uuid, primary key, default gen_random_uuid())
        // email (text, unique)
        // hashed_password (text)
        // created_at (timestamp with time zone, default now())

        // Para probar, puedes insertar un usuario:
        // INSERT INTO custom_users (email, hashed_password) VALUES ('test@example.com', crypt('password123', gen_salt('bf')));
        // (Necesitarás habilitar la extensión pgcrypto en Supabase: CREATE EXTENSION IF NOT EXISTS pgcrypto;)

        const { data: user, error } = await supabase
          .from("custom_users") // O tu tabla de usuarios personalizada
          .select("id, email, hashed_password")
          .eq("email", credentials.email as string)
          .single()

        if (error || !user) {
          console.error("Error al buscar usuario o usuario no encontrado:", error?.message)
          return null // Usuario no encontrado
        }

        // 2. Comparar la contraseña proporcionada con la contraseña hasheada
        const passwordMatch = await bcrypt.compare(credentials.password as string, user.hashed_password)

        if (passwordMatch) {
          // Si las contraseñas coinciden, devuelve el objeto de usuario
          return { id: user.id, email: user.email }
        } else {
          console.log("Contraseña incorrecta para:", credentials.email)
          return null // Contraseña incorrecta
        }
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id
      }
      return token
    },
    async session({ session, token }) {
      if (token.id) {
        session.user.id = token.id as string
      }
      return session
    },
  },
})
