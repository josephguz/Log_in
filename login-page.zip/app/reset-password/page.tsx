"use client"
import { useActionState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { updatePassword } from "@/actions/reset-password" // Importar la Server Action
import { useRouter, useSearchParams } from "next/navigation" // Importar useSearchParams

export default function ResetPasswordPage() {
  const searchParams = useSearchParams()
  const token = searchParams.get("code") // Supabase usa 'code' para el token de restablecimiento
  const router = useRouter()

  // Pasar el token como parte del estado inicial o como un campo oculto en el formulario
  const [state, formAction, isPending] = useActionState(updatePassword, { success: false, message: "" })

  // Redirigir si no hay token
  if (!token) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-red-100 text-red-800 p-4 text-center">
        <p>Token de restablecimiento de contraseña no encontrado. Por favor, solicita uno nuevo.</p>
        <Button onClick={() => router.push("/forgot-password")} className="mt-4">
          Solicitar nuevo enlace
        </Button>
      </div>
    )
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center p-4">
      <Image
        src="/images/login-hero-bg.jpg" // Asegúrate de que esta ruta sea correcta
        alt="Astronaut floating above a planet with a swirling vortex"
        fill
        style={{ objectFit: "cover" }}
        quality={100}
        priority
        className="absolute inset-0 z-0"
      />

      <form
        action={formAction}
        className="relative z-20 w-full max-w-md rounded-xl border border-black bg-white/90 p-8 shadow-lg backdrop-blur-sm"
      >
        <h2 className="mb-5 text-center text-2xl font-bold text-black">Establecer Nueva Contraseña</h2>
        {state?.message && (
          <div
            className={`mb-4 rounded-md border p-3 text-center text-sm ${
              state.success ? "border-green-500 bg-green-100 text-green-800" : "border-red-500 bg-red-100 text-red-800"
            }`}
            role="alert"
          >
            {state.message}
          </div>
        )}
        <input type="hidden" name="token" value={token} /> {/* Campo oculto para el token */}
        <div className="mb-5">
          <Label htmlFor="password" className="mb-1 block text-black">
            Nueva Contraseña
          </Label>
          <Input
            id="password"
            type="password"
            name="password" // Importante para FormData
            required
            className="w-full rounded-lg border-2 border-gray-300 bg-gray-50 px-4 py-3 text-base text-black outline-none transition-all duration-300 placeholder:text-gray-600 focus:border-black focus:bg-gray-100"
            placeholder="********"
          />
        </div>
        <div className="mb-5">
          <Label htmlFor="confirmPassword" className="mb-1 block text-black">
            Confirmar Nueva Contraseña
          </Label>
          <Input
            id="confirmPassword"
            type="password"
            name="confirmPassword" // Importante para FormData
            required
            className="w-full rounded-lg border-2 border-gray-300 bg-gray-50 px-4 py-3 text-base text-black outline-none transition-all duration-300 placeholder:text-gray-600 focus:border-black focus:bg-gray-100"
            placeholder="********"
          />
        </div>
        <Button
          type="submit"
          disabled={isPending}
          className="w-full rounded-lg border-none bg-gradient-to-r from-gray-300 to-gray-400 py-3.5 text-lg font-bold uppercase text-black shadow-md transition-all duration-300 ease-in-out hover:-translate-y-1 hover:from-gray-400 hover:to-gray-300 hover:shadow-lg active:translate-y-0 active:shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isPending ? "Actualizando..." : "Restablecer Contraseña"}
        </Button>
        <div className="mt-6 text-center text-sm text-black">
          <p>
            ¿Ya tienes una cuenta?{" "}
            <a href="/login" className="font-semibold text-black hover:underline">
              Iniciar Sesión
            </a>
          </p>
          <p className="mt-4">
            <a href="/" className="font-semibold text-black hover:underline">
              Volver al Inicio
            </a>
          </p>
        </div>
      </form>
    </div>
  )
}
