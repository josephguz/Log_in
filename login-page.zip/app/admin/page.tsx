import { getServerSession } from "next-auth/next" // Importación corregida
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import { createSupabaseServerClient } from "@/lib/supabase"
import AdminUserTable from "@/components/admin-user-table"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default async function AdminPage() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/login")
  }

  if (session.user?.role !== "admin") {
    redirect("/welcome")
  }

  const supabase = createSupabaseServerClient()
  const { data: users, error } = await supabase.from("custom_users").select("id, email, is_approved, role, created_at")

  if (error) {
    console.error("Error fetching users for admin page:", error.message)
    return (
      <div className="min-h-screen flex items-center justify-center bg-red-100 text-red-800">
        Error al cargar usuarios: {error.message}
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <h1 className="text-4xl font-bold mb-8 text-center text-gray-800">Panel de Administración de Usuarios</h1>
      <div className="flex justify-end mb-4">
        <Link href="/">
          <Button variant="outline">Volver al Inicio</Button>
        </Link>
      </div>
      <AdminUserTable initialUsers={users || []} />
    </div>
  )
}
