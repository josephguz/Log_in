import type React from "react"
import type { Metadata } from "next"
import "./globals.css"
import AuthProvider from "@/components/auth-provider" // Importar AuthProvider

export const metadata: Metadata = {
  title: "Mi App de Login",
  description: "Aplicación de login con Next.js",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es">
      <body>
        <AuthProvider>{children}</AuthProvider> {/* Envolver children con AuthProvider */}
      </body>
    </html>
  )
}
