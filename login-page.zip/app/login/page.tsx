"use client"

import type React from "react"
import { useState } from "react"
import Image from "next/image"
import { signIn } from "next-auth/react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const router = useRouter()
  const searchParams = useSearchParams()
  const resetSuccess = searchParams.get("reset") === "success"

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setIsSubmitting(true)

    if (!email || !password) {
      setError("Por favor, ingresa tu correo y contraseña.")
      setIsSubmitting(false)
      return
    }

    try {
      const result = await signIn("credentials", {
        redirect: false,
        email,
        password,
      })

      if (result?.error) {
        console.error("Error de inicio de sesión de NextAuth:", result.error)
        setError(result.error || "Correo electrónico o contraseña incorrectos.")
      } else if (result?.ok) {
        router.push("/welcome")
      }
    } catch (err: any) {
      console.error("Error durante el inicio de sesión (catch):", err)
      if (err instanceof Response && err.headers.get("content-type")?.includes("text/html")) {
        const errorText = await err.text()
        console.error("Respuesta de error HTML:", errorText)
        setError("Ocurrió un error inesperado en el servidor. Por favor, revisa los logs.")
      } else {
        setError("Ocurrió un error inesperado. Inténtalo de nuevo.")
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center p-4">
      <Image
        src="/images/login-hero-bg.jpg" // Asegúrate de que esta ruta sea correcta
        alt="Astronaut floating above a planet with a swirling vortex"
        fill
        style={{ objectOnly: "cover" }}
        quality={100}
        priority
        className="absolute inset-0 z-0"
      />

      <form
        onSubmit={handleSubmit}
        className="relative z-20 w-full max-w-md rounded-xl border border-black bg-white/90 p-8 shadow-lg backdrop-blur-sm"
      >
        <h2 className="mb-5 text-center text-2xl font-bold text-black">LOGIN</h2>

        {resetSuccess && (
          <div
            className="mb-4 rounded-md border border-green-500 bg-green-100 p-3 text-center text-sm text-green-800"
            role="alert"
          >
            ¡Contraseña restablecida exitosamente! Ya puedes iniciar sesión con tu nueva contraseña.
          </div>
        )}

        {error && (
          <div
            className="mb-4 rounded-md border border-red-500 bg-red-100 p-3 text-center text-sm text-red-800"
            role="alert"
          >
            {error}
          </div>
        )}

        <div className="mb-5">
          <Label htmlFor="email" className="mb-1 block text-black">
            Email
          </Label>
          <Input
            id="email"
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full rounded-lg border-2 border-gray-300 bg-gray-50 px-4 py-3 text-base text-black outline-none transition-all duration-300 placeholder:text-gray-600 focus:border-black focus:bg-gray-100"
            placeholder="test@example.com"
          />
        </div>

        <div className="mb-5">
          <Label htmlFor="password" className="mb-1 block text-black">
            Contraseña
          </Label>
          <Input
            id="password"
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full rounded-lg border-2 border-gray-300 bg-gray-50 px-4 py-3 text-base text-black outline-none transition-all duration-300 placeholder:text-gray-600 focus:border-black focus:bg-gray-100"
            placeholder="password123"
          />
        </div>

        <div className="mb-5 flex items-center justify-between text-sm text-black">
          <label htmlFor="remember" className="flex items-center gap-2">
            <input type="checkbox" id="remember" className="form-checkbox h-4 w-4 accent-black" />
            <p>Remember me</p>
          </label>
          <a href="/forgot-password" className="font-semibold text-black hover:underline">
            Forgot password?
          </a>
        </div>

        <Button
          type="submit"
          disabled={isSubmitting}
          className="w-full rounded-lg border-none bg-gradient-to-r from-gray-300 to-gray-400 py-3.5 text-lg font-bold uppercase text-black shadow-md transition-all duration-300 ease-in-out hover:-translate-y-1 hover:from-gray-400 hover:to-gray-300 hover:shadow-lg active:translate-y-0 active:shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSubmitting ? "Ingresando..." : "Ingresar"}
        </Button>

        <div className="mt-6 text-center text-sm text-black">
          <p>
            Don't have an account?{" "}
            <a href="/register" className="font-semibold text-black hover:underline">
              Register
            </a>
          </p>
          <p className="mt-4">
            <a href="/" className="font-semibold text-black hover:underline">
              Volver al Inicio
            </a>
          </p>
        </div>
      </form>
    </div>
  )
}
