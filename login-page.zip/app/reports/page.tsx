"use client"

import { useState, useEffect } from "react"
import { useActionState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  createClient,
  createEquipment,
  createServiceReport,
  getClients,
  getEquipmentByClientId,
  getServiceReportsByEquipmentId,
  type Client,
  type Equipment,
  type ServiceReport,
} from "@/actions/reports"
import Link from "next/link"
import { toast } from "@/hooks/use-toast" // Asumiendo que tienes un hook useToast o similar
import { useDebounce } from "@/hooks/use-debounce" // Importar el hook de debounce

export default function ReportsPage() {
  const [clients, setClients] = useState<Client[]>([])
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null)
  const [equipment, setEquipment] = useState<Equipment[]>([])
  const [selectedEquipmentId, setSelectedEquipmentId] = useState<string | null>(null)
  const [serviceReports, setServiceReports] = useState<ServiceReport[]>([])

  // Estado para el buscador de clientes
  const [clientSearchQuery, setClientSearchQuery] = useState("")
  const debouncedClientSearchQuery = useDebounce(clientSearchQuery, 500) // Debounce de 500ms

  // Estado para el buscador de equipos
  const [equipmentSearchQuery, setEquipmentSearchQuery] = useState("")
  const debouncedEquipmentSearchQuery = useDebounce(equipmentSearchQuery, 500) // Debounce de 500ms

  // Action states for forms
  const [clientFormState, clientFormAction, isCreatingClient] = useActionState(createClient, {
    success: false,
    message: "",
  })
  const [equipmentFormState, equipmentFormAction, isCreatingEquipment] = useActionState(createEquipment, {
    success: false,
    message: "",
  })
  const [reportFormState, reportFormAction, isCreatingReport] = useActionState(createServiceReport, {
    success: false,
    message: "",
  })

  // Fetch clients on component mount and when search query changes
  useEffect(() => {
    const fetchClientsData = async () => {
      const data = await getClients(debouncedClientSearchQuery) // Pasar el término de búsqueda
      setClients(data)
      // Si el cliente seleccionado ya no está en la lista filtrada, deseleccionarlo
      if (selectedClientId && !data.some((client) => client.id === selectedClientId)) {
        setSelectedClientId(null)
      }
      // Si no hay cliente seleccionado y hay clientes disponibles, seleccionar el primero
      if (!selectedClientId && data.length > 0) {
        setSelectedClientId(data[0].id)
      }
    }
    fetchClientsData()
  }, [debouncedClientSearchQuery, clientFormState.success]) // Refetch if a new client is created or search query changes

  // Fetch equipment when selectedClientId or equipmentSearchQuery changes
  useEffect(() => {
    const fetchEquipmentData = async () => {
      if (selectedClientId) {
        const data = await getEquipmentByClientId(selectedClientId, debouncedEquipmentSearchQuery) // Pasar el término de búsqueda de equipo
        setEquipment(data)
        // Si el equipo seleccionado ya no está en la lista filtrada, deseleccionarlo
        if (selectedEquipmentId && !data.some((eq) => eq.id === selectedEquipmentId)) {
          setSelectedEquipmentId(null)
        }
        // Si no hay equipo seleccionado y hay equipos disponibles, seleccionar el primero
        if (!selectedEquipmentId && data.length > 0) {
          setSelectedEquipmentId(data[0].id)
        }
      } else {
        setEquipment([])
        setSelectedEquipmentId(null)
      }
    }
    fetchEquipmentData()
  }, [selectedClientId, debouncedEquipmentSearchQuery, equipmentFormState.success]) // Refetch if new equipment is created or search query changes

  // Fetch service reports when selectedEquipmentId changes
  useEffect(() => {
    const fetchServiceReportsData = async () => {
      if (selectedEquipmentId) {
        const data = await getServiceReportsByEquipmentId(selectedEquipmentId)
        setServiceReports(data)
      } else {
        setServiceReports([])
      }
    }
    fetchServiceReportsData()
  }, [selectedEquipmentId, reportFormState.success]) // Refetch if new report is created

  // Handle toast messages for form submissions
  useEffect(() => {
    if (clientFormState.message) {
      toast({
        title: clientFormState.success ? "Éxito" : "Error",
        description: clientFormState.message,
        variant: clientFormState.success ? "default" : "destructive",
      })
    }
  }, [clientFormState])

  useEffect(() => {
    if (equipmentFormState.message) {
      toast({
        title: equipmentFormState.success ? "Éxito" : "Error",
        description: equipmentFormState.message,
        variant: equipmentFormState.success ? "default" : "destructive",
      })
    }
  }, [equipmentFormState])

  useEffect(() => {
    if (reportFormState.message) {
      toast({
        title: reportFormState.success ? "Éxito" : "Error",
        description: reportFormState.message,
        variant: reportFormState.success ? "default" : "destructive",
      })
    }
  }, [reportFormState])

  return (
    <div className="container mx-auto py-10 px-4">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-800">Gestión de Reportes de Servicio</h1>
        <Link href="/">
          <Button variant="outline">Volver al Inicio</Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sección de Clientes */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Clientes</CardTitle>
          </CardHeader>
          <CardContent>
            <form action={clientFormAction} className="space-y-4 mb-6">
              <h3 className="text-lg font-semibold">Añadir Nuevo Cliente</h3>
              <div>
                <Label htmlFor="clientName">Nombre del Cliente</Label>
                <Input id="clientName" name="clienteNombre" required placeholder="Nombre de la Empresa" />
              </div>
              <div>
                <Label htmlFor="contactPerson">Persona de Contacto</Label>
                <Input id="contactPerson" name="contact_person" placeholder="Juan Pérez" />
              </div>
              <div>
                <Label htmlFor="clientPhone">Teléfono</Label>
                <Input id="clientPhone" name="clienteTelefono" placeholder="123-456-7890" />
              </div>
              <div>
                <Label htmlFor="clientEmail">Email</Label>
                <Input id="clientEmail" name="clienteEmail" type="email" placeholder="contacto@empresa.com" />
              </div>
              <div>
                <Label htmlFor="clientAddress">Dirección</Label>
                <Input id="clientAddress" name="address" placeholder="Calle Falsa 123" />
              </div>
              <Button type="submit" disabled={isCreatingClient}>
                {isCreatingClient ? "Creando..." : "Crear Cliente"}
              </Button>
            </form>

            <h3 className="text-lg font-semibold mb-2">Seleccionar Cliente Existente</h3>
            <div className="mb-4">
              <Label htmlFor="clientSearch">Buscar Cliente</Label>
              <Input
                id="clientSearch"
                type="text"
                placeholder="Buscar por nombre o email..."
                value={clientSearchQuery}
                onChange={(e) => setClientSearchQuery(e.target.value)}
                className="w-full"
              />
            </div>
            <Select value={selectedClientId || ""} onValueChange={setSelectedClientId}>
              <SelectTrigger className="w-full border-gray-400 focus:border-black focus:ring-2 focus:ring-black">
                <SelectValue placeholder="Selecciona un cliente" />
              </SelectTrigger>
              <SelectContent className="bg-white">
                {" "}
                {/* Añadido bg-white */}
                {clients.length > 0 ? (
                  clients.map((client) => (
                    <SelectItem key={client.id} value={client.id}>
                      {client.name} ({client.email})
                    </SelectItem>
                  ))
                ) : (
                  <SelectItem value="no-clients" disabled>
                    No se encontraron clientes
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {/* Sección de Equipos */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Equipos del Cliente</CardTitle>
          </CardHeader>
          <CardContent>
            {selectedClientId ? (
              <>
                <form action={equipmentFormAction} className="space-y-4 mb-6">
                  <h3 className="text-lg font-semibold">Añadir Nuevo Equipo</h3>
                  <input type="hidden" name="client_id" value={selectedClientId} />
                  <div>
                    <Label htmlFor="equipmentName">Nombre del Equipo</Label>
                    <Input id="equipmentName" name="name" required placeholder="Servidor Principal" />
                  </div>
                  <div>
                    <Label htmlFor="equipmentModel">Modelo</Label>
                    <Input id="equipmentModel" name="model" placeholder="Dell PowerEdge R740" />
                  </div>
                  <div>
                    <Label htmlFor="equipmentBrand">Marca</Label>
                    <Input id="equipmentBrand" name="brand" placeholder="HP, Dell, Cisco..." />
                  </div>
                  <div>
                    <Label htmlFor="serialNumber">Número de Serie</Label>
                    <Input id="serialNumber" name="serial_number" placeholder="SN123456789" />
                  </div>
                  <div>
                    <Label htmlFor="inventoryNumber">Número de Inventario</Label>
                    <Input id="inventoryNumber" name="inventory_number" placeholder="INV-001" />
                  </div>
                  <div>
                    <Label htmlFor="equipmentLocation">Ubicación</Label>
                    <Input id="equipmentLocation" name="location" placeholder="Sala de Servidores" />
                  </div>
                  <Button type="submit" disabled={isCreatingEquipment}>
                    {isCreatingEquipment ? "Creando..." : "Crear Equipo"}
                  </Button>
                </form>

                <h3 className="text-lg font-semibold mb-2">Seleccionar Equipo Existente</h3>
                <div className="mb-4">
                  <Label htmlFor="equipmentSearch">Buscar Equipo</Label>
                  <Input
                    id="equipmentSearch"
                    type="text"
                    placeholder="Buscar por nombre, modelo, serie..."
                    value={equipmentSearchQuery}
                    onChange={(e) => setEquipmentSearchQuery(e.target.value)}
                    className="w-full"
                  />
                </div>
                <Select value={selectedEquipmentId || ""} onValueChange={setSelectedEquipmentId}>
                  <SelectTrigger className="w-full border-gray-400 focus:border-black focus:ring-2 focus:ring-black">
                    <SelectValue placeholder="Selecciona un equipo" />
                  </SelectTrigger>
                  <SelectContent className="bg-white">
                    {" "}
                    {/* Añadido bg-white */}
                    {equipment.length > 0 ? (
                      equipment.map((eq) => (
                        <SelectItem key={eq.id} value={eq.id}>
                          {eq.name} ({eq.serial_number})
                        </SelectItem>
                      ))
                    ) : (
                      <SelectItem value="no-equipment" disabled>
                        No hay equipos para este cliente o no se encontraron resultados
                      </SelectItem>
                    )}
                  </SelectContent>
                </Select>

                {/* Botón para ir a crear reporte de servicio */}
                {selectedClientId && selectedEquipmentId && (
                  <div className="mt-6 text-center">
                    <Link href={`/service-reports?clientId=${selectedClientId}&equipmentId=${selectedEquipmentId}`}>
                      <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-md">
                        Crear Reporte de Servicio
                      </Button>
                    </Link>
                  </div>
                )}
              </>
            ) : (
              <p className="text-gray-500">Selecciona un cliente para ver y añadir equipos.</p>
            )}
          </CardContent>
        </Card>

        {/* Sección de Reportes de Servicio (existente, no se modifica para crear aquí) */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Reportes de Servicio Existentes</CardTitle>
          </CardHeader>
          <CardContent>
            {selectedEquipmentId ? (
              <>
                {/* Este formulario se moverá a la nueva página de service-reports */}
                {/* <form action={reportFormAction} className="space-y-4 mb-6">
                  <h3 className="text-lg font-semibold">Crear Nuevo Reporte</h3>
                  <input type="hidden" name="equipment_id" value={selectedEquipmentId} />
                  <div>
                    <Label htmlFor="reportDate">Fecha del Reporte</Label>
                    <Input
                      id="reportDate"
                      name="report_date"
                      type="date"
                      required
                      defaultValue={new Date().toISOString().split("T")[0]}
                    />
                  </div>
                  <div>
                    <Label htmlFor="serviceType">Tipo de Servicio</Label>
                    <Input id="serviceType" name="service_type" required placeholder="Mantenimiento Preventivo" />
                  </div>
                  <div>
                    <Label htmlFor="description">Descripción</Label>
                    <textarea id="description" name="description" placeholder="Detalles del servicio realizado..." />
                  </div>
                  <div>
                    <Label htmlFor="technicianNotes">Notas del Técnico</Label>
                    <textarea id="technicianNotes" name="technician_notes" placeholder="Observaciones adicionales..." />
                  </div>
                  <div>
                    <Label htmlFor="status">Estado</Label>
                    <select name="status" defaultValue="Pendiente">
                      <option value="Pendiente">Pendiente</option>
                      <option value="En Progreso">En Progreso</option>
                      <option value="Completado">Completado</option>
                      <option value="Cancelado">Cancelado</option>
                    </select>
                  </div>
                  <Button type="submit" disabled={isCreatingReport}>
                    {isCreatingReport ? "Creando..." : "Crear Reporte"}
                  </Button>
                </form> */}

                <h3 className="text-lg font-semibold mb-2">Reportes Existentes</h3>
                {serviceReports.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Fecha</TableHead>
                        <TableHead>Tipo</TableHead>
                        <TableHead>Estado</TableHead>
                        <TableHead>Descripción</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {serviceReports.map((report) => (
                        <TableRow key={report.id}>
                          <TableCell>{new Date(report.report_date).toLocaleDateString()}</TableCell>
                          <TableCell>{report.service_type}</TableCell>
                          <TableCell>{report.status}</TableCell>
                          <TableCell className="text-sm text-gray-600">
                            {report.description?.substring(0, 50)}...
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <p className="text-gray-500">No hay reportes para este equipo.</p>
                )}
              </>
            ) : (
              <p className="text-gray-500">Selecciona un equipo para ver y crear reportes.</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
