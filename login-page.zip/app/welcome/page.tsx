import { getServerSession } from "next-auth/next" // Importación corregida
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { ChevronDownIcon } from "lucide-react"
import LogoutButton from "@/components/logout-button"

export default async function WelcomePage({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/login")
  }

  const isAdmin = session.user?.role === "admin"

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-purple-600 to-indigo-800 text-white p-4">
      <h1 className="text-5xl font-extrabold mb-6 text-center">¡Bienvenido, {session.user?.email || "Usuario"}!</h1>
      <p className="text-xl mb-8 text-center max-w-prose">
        Has iniciado sesión exitosamente. Esta es tu página de bienvenida.
      </p>

      <div className="flex flex-col sm:flex-row gap-4 mb-8">
        {isAdmin && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button className="bg-white text-purple-700 hover:bg-gray-100 font-bold py-3 px-6 rounded-full shadow-lg transition-all duration-300 ease-in-out hover:scale-105 flex items-center gap-2">
                Acceso Rápido Admin <ChevronDownIcon className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56">
              <DropdownMenuItem asChild>
                <Link href="/admin">Panel de Administración</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/register">Página de Registro</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/forgot-password">Restablecer Contraseña</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/">Página Principal</Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
        <Link href="/reports">
          <Button className="bg-white text-purple-700 hover:bg-gray-100 font-bold py-3 px-6 rounded-full shadow-lg transition-all duration-300 ease-in-out hover:scale-105">
            Gestión de Reportes
          </Button>
        </Link>
        <Link href="/">
          <Button className="bg-white text-purple-700 hover:bg-gray-100 font-bold py-3 px-6 rounded-full shadow-lg transition-all duration-300 ease-in-out hover:scale-105">
            Ir a la Página Principal
          </Button>
        </Link>
        <LogoutButton />
      </div>
    </div>
  )
}
