import Link from "next/link"

export default function PendingApprovalPage({
  searchParams, // Añadir searchParams a las props
}: {
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-blue-600 to-cyan-800 text-white p-4 text-center">
      <h1 className="text-5xl font-extrabold mb-6">¡Registro Exitoso!</h1>
      <p className="text-xl mb-8 max-w-prose">
        Tu cuenta ha sido creada. Para acceder, un administrador debe validar tu identidad. Recibirás una notificación
        cuando tu cuenta sea aprobada.
      </p>
      <Link
        href="/" // Cambiado de "/login" a "/"
        className="bg-white text-blue-700 hover:bg-gray-100 font-bold py-3 px-6 rounded-full shadow-lg transition-all duration-300 ease-in-out hover:scale-105"
      >
        Volver al Inicio {/* Cambiado de "Volver al Inicio de Sesión" */}
      </Link>
    </div>
  )
}
