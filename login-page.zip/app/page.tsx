import { getServerSession } from "next-auth/next" // Importación corregida
import { authOptions } from "@/lib/auth"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default async function HomePage() {
  const session = await getServerSession(authOptions)

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="text-center">
        {session ? (
          <>
            <h1 className="text-4xl font-bold mb-4">¡Bienvenido de nuevo, {session.user?.email || "Usuario"}!</h1>
            <p className="text-gray-600 mb-8">Has iniciado sesión.</p>
            <Link href="/welcome">
              <Button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                Ir al Dashboard
              </Button>
            </Link>
          </>
        ) : (
          <>
            <h1 className="text-4xl font-bold mb-4">Bienvenido</h1>
            <p className="text-gray-600 mb-8">Esta es la página principal</p>
            <Link href="/login">
              <Button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                Ir a Login
              </Button>
            </Link>
          </>
        )}
      </div>
    </div>
  )
}
