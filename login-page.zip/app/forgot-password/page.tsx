"use client"
import { useActionState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { requestPasswordReset } from "@/actions/password-reset" // Importar la Server Action

export default function ForgotPasswordPage() {
  const [state, formAction, isPending] = useActionState(requestPasswordReset, { success: false, message: "" })

  return (
    <div className="relative flex min-h-screen items-center justify-center p-4">
      <Image
        src="/images/login-hero-bg.jpg" // Asegúrate de que esta ruta sea correcta
        alt="Astronaut floating above a planet with a swirling vortex"
        fill
        style={{ objectFit: "cover" }}
        quality={100}
        priority
        className="absolute inset-0 z-0"
      />

      <form
        action={formAction}
        className="relative z-20 w-full max-w-md rounded-xl border border-black bg-white/90 p-8 shadow-lg backdrop-blur-sm"
      >
        <h2 className="mb-5 text-center text-2xl font-bold text-black">¿Olvidaste tu Contraseña?</h2>

        {state?.message && (
          <div
            className={`mb-4 rounded-md border p-3 text-center text-sm ${
              state.success ? "border-green-500 bg-green-100 text-green-800" : "border-red-500 bg-red-100 text-red-800"
            }`}
            role="alert"
          >
            {state.message}
          </div>
        )}

        <div className="mb-5">
          <Label htmlFor="email" className="mb-1 block text-black">
            Email
          </Label>
          <Input
            id="email"
            type="email"
            name="email" // Importante para FormData
            required
            className="w-full rounded-lg border-2 border-gray-300 bg-gray-50 px-4 py-3 text-base text-black outline-none transition-all duration-300 placeholder:text-gray-600 focus:border-black focus:bg-gray-100"
            placeholder="tu@ejemplo.com"
          />
        </div>

        <Button
          type="submit"
          disabled={isPending}
          className="w-full rounded-lg border-none bg-gradient-to-r from-gray-300 to-gray-400 py-3.5 text-lg font-bold uppercase text-black shadow-md transition-all duration-300 ease-in-out hover:-translate-y-1 hover:from-gray-400 hover:to-gray-300 hover:shadow-lg active:translate-y-0 active:shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isPending ? "Enviando..." : "Enviar Enlace de Restablecimiento"}
        </Button>

        <div className="mt-6 text-center text-sm text-black">
          <p>
            ¿Recordaste tu contraseña?{" "}
            <a href="/login" className="font-semibold text-black hover:underline">
              Volver al Inicio de Sesión
            </a>
          </p>
          <p className="mt-4">
            <a href="/" className="font-semibold text-black hover:underline">
              Volver al Inicio
            </a>
          </p>
        </div>
      </form>
    </div>
  )
}
