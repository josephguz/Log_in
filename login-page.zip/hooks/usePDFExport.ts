"use client"

import html2canvas from "html2canvas"
import jsPDF from "jspdf"
import { useCallback } from "react"

export function usePDFExport() {
  const exportToPDF = useCallback(async (elementIds: string[], filename = "documento", data: any = {}) => {
    try {
      const doc = new jsPDF("p", "mm", "a4") // 'p' for portrait, 'mm' for millimeters, 'a4' size
      let yOffset = 10 // Initial Y offset for content

      for (const id of elementIds) {
        const element = document.getElementById(id)
        if (element) {
          const canvas = await html2canvas(element, {
            scale: 2, // Increase scale for better resolution
            useCORS: true, // Important for images from external sources
          })

          const imgData = canvas.toDataURL("image/png")
          const imgWidth = 210 - 20 // A4 width (210mm) - 20mm margin
          const pageHeight = 297 - 20 // A4 height (297mm) - 20mm margin
          const imgHeight = (canvas.height * imgWidth) / canvas.width

          let heightLeft = imgHeight

          if (yOffset !== 10) {
            doc.addPage() // Add a new page for subsequent elements if not the first
            yOffset = 10
          }

          while (heightLeft >= 0) {
            const pageData = imgData
            const sX = 0
            const sY = imgHeight - heightLeft
            const sWidth = canvas.width
            const sHeight = Math.min(heightLeft, (pageHeight * canvas.width) / imgWidth)

            doc.addImage(
              pageData,
              "PNG",
              10, // X position (left margin)
              yOffset, // Y position
              imgWidth, // Width
              (sHeight * imgWidth) / sWidth, // Height
              undefined,
              "FAST",
              sX,
              sY,
              sWidth,
              sHeight,
            )
            heightLeft -= (pageHeight * canvas.width) / imgWidth
            if (heightLeft > 0) {
              doc.addPage()
              yOffset = 10
            }
          }
        } else {
          console.warn(`Element with ID "${id}" not found for PDF export.`)
        }
      }

      doc.save(`${filename}.pdf`)
      return true
    } catch (error) {
      console.error("Error exporting to PDF:", error)
      return false
    }
  }, [])

  return { exportToPDF }
}
